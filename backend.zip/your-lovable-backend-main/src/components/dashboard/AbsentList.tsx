import React from 'react';
import { Student } from '@/types/attendance';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Phone, CheckCircle2 } from 'lucide-react';

interface AbsentListProps {
  students: Student[];
  presentIds: Set<string>;
}

export const AbsentList: React.FC<AbsentListProps> = ({ students, presentIds }) => {
  const absentStudents = students.filter((s) => !presentIds.has(s.id));

  if (absentStudents.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-success">
        <CheckCircle2 className="mb-2 h-12 w-12" />
        <p className="font-medium">All students are present today!</p>
      </div>
    );
  }

  return (
    <div className="divide-y">
      {absentStudents.map((student) => (
        <div
          key={student.id}
          className="flex items-center gap-4 bg-warning/5 p-4 transition-colors hover:bg-destructive/5"
        >
          <Avatar className="h-10 w-10 border-2 border-destructive">
            <AvatarImage src={student.avatar_url || undefined} />
            <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <p className="font-bold">{student.name}</p>
            <p className="text-sm text-muted-foreground">RFID: {student.rfid_id}</p>
            {student.phone && (
              <div className="mt-1 inline-flex items-center gap-1 rounded bg-destructive/10 px-2 py-0.5 text-xs font-semibold text-destructive">
                <Phone className="h-3 w-3" />
                {student.phone}
              </div>
            )}
          </div>

          <Badge variant="destructive">Absent</Badge>
        </div>
      ))}
    </div>
  );
};
