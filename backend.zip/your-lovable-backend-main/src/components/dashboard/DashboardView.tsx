import React, { useState } from 'react';
import { useStudents } from '@/hooks/useStudents';
import { useAttendanceLogs, useMarkAttendance } from '@/hooks/useAttendance';
import { StatCard } from './StatCard';
import { PieChart } from './PieChart';
import { AttendanceTable } from './AttendanceTable';
import { AbsentList } from './AbsentList';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, AlertTriangle } from 'lucide-react';

export const DashboardView: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split('T')[0]
  );

  const { data: students = [], isLoading: studentsLoading } = useStudents();
  const { data: logs = [], isLoading: logsLoading } = useAttendanceLogs(selectedDate);

  const presentIds = new Set(logs.map((l) => l.student_id));
  const presentCount = presentIds.size;
  const totalCount = students.length;
  const absentCount = totalCount - presentCount;

  const downloadReport = () => {
    let csvContent = "data:text/csv;charset=utf-8,Name,Student ID,Phone,Date,Time,Method,Status\n";
    
    students.forEach((student) => {
      const log = logs.find((l) => l.student_id === student.id);
      
      if (log) {
        csvContent += `"${student.name}",${student.rfid_id},"${student.phone || 'N/A'}",${log.date},${log.time},${log.method},Present\n`;
      } else {
        csvContent += `"${student.name}",${student.rfid_id},"${student.phone || 'N/A'}",${selectedDate},-,-,Absent\n`;
      }
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Attendance_Report_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="animate-fadeIn space-y-6">
      {/* Stats Grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          title="Present Today"
          value={presentCount}
          variant="success"
          chart={<PieChart present={presentCount} total={totalCount} />}
        />
        <StatCard title="Total Students" value={totalCount} />
        <StatCard title="Absent Today" value={absentCount} variant="danger" />
      </div>

      {/* Present Logs Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle>Present Students Logs</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
            />
            <Button onClick={downloadReport} size="sm">
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <AttendanceTable logs={logs} isLoading={logsLoading} />
        </CardContent>
      </Card>

      {/* Absent List */}
      <Card className="border-l-4 border-l-destructive">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Absent Students List
          </CardTitle>
          <span className="text-sm text-muted-foreground">Includes Contact Info</span>
        </CardHeader>
        <CardContent className="p-0">
          {studentsLoading ? (
            <div className="p-8 text-center text-muted-foreground">Loading...</div>
          ) : (
            <AbsentList students={students} presentIds={presentIds} />
          )}
        </CardContent>
      </Card>
    </div>
  );
};
