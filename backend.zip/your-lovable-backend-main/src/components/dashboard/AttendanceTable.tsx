import React from 'react';
import { AttendanceLogWithStudent } from '@/types/attendance';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface AttendanceTableProps {
  logs: AttendanceLogWithStudent[];
  isLoading: boolean;
}

export const AttendanceTable: React.FC<AttendanceTableProps> = ({ logs, isLoading }) => {
  if (isLoading) {
    return (
      <div className="p-8 text-center text-muted-foreground">
        Loading attendance records...
      </div>
    );
  }

  if (logs.length === 0) {
    return (
      <div className="p-8 text-center text-muted-foreground">
        No records for this date.
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Time</TableHead>
          <TableHead>Student Name</TableHead>
          <TableHead>ID</TableHead>
          <TableHead>Method</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {logs.map((log) => (
          <TableRow key={log.id}>
            <TableCell>{log.time}</TableCell>
            <TableCell>
              <div className="flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={log.students?.avatar_url || undefined} />
                  <AvatarFallback>
                    {log.students?.name?.charAt(0) || 'S'}
                  </AvatarFallback>
                </Avatar>
                {log.students?.name || 'Unknown'}
              </div>
            </TableCell>
            <TableCell>{log.students?.rfid_id || 'N/A'}</TableCell>
            <TableCell>
              <Badge variant="secondary">{log.method}</Badge>
            </TableCell>
            <TableCell>
              <Badge className="bg-success/20 text-success hover:bg-success/30">
                Present
              </Badge>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};
