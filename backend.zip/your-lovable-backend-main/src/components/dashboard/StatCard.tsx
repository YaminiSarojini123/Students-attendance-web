import React from 'react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: number | string;
  variant?: 'default' | 'success' | 'danger';
  chart?: React.ReactNode;
}

export const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  variant = 'default',
  chart 
}) => {
  return (
    <div className="flex items-center justify-between rounded-xl border bg-card p-6 shadow-sm">
      <div>
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <p className={cn(
          'text-3xl font-bold',
          variant === 'success' && 'text-success',
          variant === 'danger' && 'text-destructive'
        )}>
          {value}
        </p>
      </div>
      {chart}
    </div>
  );
};
