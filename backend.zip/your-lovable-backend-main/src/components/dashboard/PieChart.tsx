import React from 'react';

interface PieChartProps {
  present: number;
  total: number;
}

export const PieChart: React.FC<PieChartProps> = ({ present, total }) => {
  const percentage = total > 0 ? (present / total) * 100 : 0;
  
  return (
    <div 
      className="h-16 w-16 rounded-full transition-all"
      style={{
        background: total === 0 
          ? 'hsl(var(--muted))' 
          : `conic-gradient(hsl(var(--success)) 0% ${percentage}%, hsl(var(--destructive)) ${percentage}% 100%)`
      }}
    />
  );
};
