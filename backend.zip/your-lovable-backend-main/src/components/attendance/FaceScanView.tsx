import React, { useRef, useState, useEffect } from 'react';
import { useStudents } from '@/hooks/useStudents';
import { useMarkAttendance, useAttendanceLogs } from '@/hooks/useAttendance';
import { Button } from '@/components/ui/button';
import { Camera, CameraOff } from 'lucide-react';

export const FaceScanView: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);

  const { data: students = [] } = useStudents();
  const today = new Date().toISOString().split('T')[0];
  const { data: logs = [] } = useAttendanceLogs(today);
  const markAttendance = useMarkAttendance();

  const presentIds = new Set(logs.map((l) => l.student_id));

  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [stream]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setStream(mediaStream);
      setCameraActive(true);
    } catch (err) {
      console.error('Camera access denied:', err);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const simulateFaceScan = () => {
    setIsScanning(true);

    setTimeout(() => {
      // Find students not yet marked present
      const availableStudents = students.filter((s) => !presentIds.has(s.id));
      const pool = availableStudents.length > 0 ? availableStudents : students;
      
      if (pool.length > 0) {
        const randomStudent = pool[Math.floor(Math.random() * pool.length)];
        markAttendance.mutate({
          studentId: randomStudent.id,
          method: 'Face ID',
          date: today,
        });
      }

      setIsScanning(false);
    }, 2000);
  };

  return (
    <div className="animate-fadeIn flex flex-col items-center gap-6">
      {/* Camera Viewport */}
      <div className="relative aspect-[4/3] w-full max-w-2xl overflow-hidden rounded-xl bg-black shadow-lg">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="h-full w-full scale-x-[-1] object-cover"
        />

        {/* Scan Overlay */}
        <div className="absolute inset-[20%] rounded-lg border-2 border-white/50 shadow-[0_0_0_9999px_rgba(0,0,0,0.5)]">
          {isScanning && (
            <div className="animate-scan absolute h-0.5 w-full bg-primary shadow-[0_0_10px_hsl(var(--primary))]" />
          )}
        </div>

        {/* Camera Placeholder */}
        {!cameraActive && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/90 text-muted-foreground">
            <p>Camera inactive</p>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex gap-4">
        <Button
          variant={cameraActive ? 'destructive' : 'outline'}
          onClick={cameraActive ? stopCamera : startCamera}
        >
          {cameraActive ? (
            <>
              <CameraOff className="mr-2 h-4 w-4" />
              Stop Camera
            </>
          ) : (
            <>
              <Camera className="mr-2 h-4 w-4" />
              Start Camera
            </>
          )}
        </Button>
        <Button
          onClick={simulateFaceScan}
          disabled={!cameraActive || isScanning}
        >
          {isScanning ? 'Scanning...' : 'Mark Attendance'}
        </Button>
      </div>

      <p className="max-w-md text-center text-sm text-muted-foreground">
        <strong>Note:</strong> This is a simulation. Click "Start Camera", then "Mark Attendance" to simulate AI face detection.
      </p>
    </div>
  );
};
