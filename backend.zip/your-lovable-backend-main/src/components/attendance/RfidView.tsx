import React, { useState } from 'react';
import { useStudentByRfid, useMarkAttendance } from '@/hooks/useAttendance';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { CreditCard } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export const RfidView: React.FC = () => {
  const [rfidInput, setRfidInput] = useState('');
  const today = new Date().toISOString().split('T')[0];
  
  const findStudent = useStudentByRfid();
  const markAttendance = useMarkAttendance();

  const handleSubmit = async () => {
    if (!rfidInput.trim()) return;

    try {
      const student = await findStudent.mutateAsync(rfidInput.trim());
      markAttendance.mutate({
        studentId: student.id,
        method: 'RFID Card',
        date: today,
      });
    } catch (error) {
      toast({
        title: 'ID not recognized',
        description: 'No student found with this RFID',
        variant: 'destructive',
      });
    }

    setRfidInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <div className="animate-fadeIn flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardContent className="p-8 text-center">
          <CreditCard className="mx-auto mb-4 h-16 w-16 text-primary" strokeWidth={1.5} />
          <h2 className="mb-2 text-2xl font-bold">RFID Terminal</h2>
          <p className="mb-6 text-muted-foreground">
            Swipe card or enter ID manually.
          </p>

          <div className="flex gap-2">
            <Input
              type="text"
              placeholder="Enter ID (e.g., 101)"
              value={rfidInput}
              onChange={(e) => setRfidInput(e.target.value)}
              onKeyPress={handleKeyPress}
              autoFocus
            />
            <Button onClick={handleSubmit} disabled={!rfidInput.trim()}>
              Enter
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
