import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { 
  LayoutDashboard, 
  Camera, 
  CreditCard, 
  Users, 
  User,
  HelpCircle,
  Home
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
}

interface AppSidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

export const AppSidebar: React.FC<AppSidebarProps> = ({ activeView, onViewChange }) => {
  const { hasRole } = useAuth();

  const getNavItems = (): NavItem[] => {
    if (hasRole('admin') || hasRole('teacher')) {
      return [
        { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
        { id: 'face-scan', label: 'Face Scan', icon: <Camera className="h-5 w-5" /> },
        { id: 'rfid', label: 'RFID Terminal', icon: <CreditCard className="h-5 w-5" /> },
        { id: 'students', label: 'Students List', icon: <Users className="h-5 w-5" /> },
      ];
    } else if (hasRole('student')) {
      return [
        { id: 'student-portal', label: 'My Attendance', icon: <User className="h-5 w-5" /> },
      ];
    } else if (hasRole('parent')) {
      return [
        { id: 'parent-portal', label: 'Child Lookup', icon: <HelpCircle className="h-5 w-5" /> },
      ];
    }
    return [];
  };

  const navItems = getNavItems();

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r bg-card p-6">
      <div className="mb-8 flex items-center gap-2 text-xl font-extrabold text-primary">
        <Home className="h-6 w-6" />
        EduTrack Pro
      </div>

      <nav className="flex-1 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={cn(
              'flex w-full items-center gap-3 rounded-lg px-4 py-3 text-left font-semibold transition-all',
              activeView === item.id
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-muted hover:text-primary'
            )}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>
    </aside>
  );
};
