import React, { useState } from 'react';
import { useStudents, useAddStudent, useUpdateStudent, useDeleteStudent } from '@/hooks/useStudents';
import { Student } from '@/types/attendance';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Search, Plus, Pencil, Trash2, Phone } from 'lucide-react';

export const StudentsView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Form state
  const [formName, setFormName] = useState('');
  const [formRfid, setFormRfid] = useState('');
  const [formPhone, setFormPhone] = useState('');

  const { data: students = [], isLoading } = useStudents();
  const addStudent = useAddStudent();
  const updateStudent = useUpdateStudent();
  const deleteStudent = useDeleteStudent();

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.rfid_id.includes(searchQuery)
  );

  const openAddModal = () => {
    setEditingStudent(null);
    setFormName('');
    setFormRfid('');
    setFormPhone('');
    setIsModalOpen(true);
  };

  const openEditModal = (student: Student) => {
    setEditingStudent(student);
    setFormName(student.name);
    setFormRfid(student.rfid_id);
    setFormPhone(student.phone || '');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingStudent) {
      updateStudent.mutate(
        { id: editingStudent.id, name: formName, phone: formPhone },
        { onSuccess: () => setIsModalOpen(false) }
      );
    } else {
      addStudent.mutate(
        { rfid_id: formRfid, name: formName, phone: formPhone },
        { onSuccess: () => setIsModalOpen(false) }
      );
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this student and their history?')) {
      deleteStudent.mutate(id);
    }
  };

  return (
    <div className="animate-fadeIn space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Class List</h2>
        <Button onClick={openAddModal}>
          <Plus className="mr-2 h-4 w-4" />
          Add Student
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search students..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Student Grid */}
      {isLoading ? (
        <div className="text-center text-muted-foreground">Loading students...</div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredStudents.map((student) => (
            <Card key={student.id}>
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Avatar className="mb-4 h-20 w-20">
                  <AvatarImage src={student.avatar_url || undefined} />
                  <AvatarFallback className="text-2xl">
                    {student.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-bold">{student.name}</h3>
                <p className="text-sm text-muted-foreground">ID: {student.rfid_id}</p>
                {student.phone && (
                  <p className="mt-1 flex items-center gap-1 text-sm text-primary">
                    <Phone className="h-3 w-3" />
                    {student.phone}
                  </p>
                )}
                <div className="mt-4 flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(student)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:bg-destructive/10"
                    onClick={() => handleDelete(student.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingStudent ? 'Edit Student' : 'Register Student'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rfid">RFID Card ID</Label>
              <Input
                id="rfid"
                value={formRfid}
                onChange={(e) => setFormRfid(e.target.value)}
                disabled={!!editingStudent}
                placeholder="e.g. 104"
                required={!editingStudent}
              />
              {editingStudent && (
                <p className="text-xs text-muted-foreground">
                  ID cannot be changed when editing.
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={formPhone}
                onChange={(e) => setFormPhone(e.target.value)}
                placeholder="e.g. 555-0123"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsModalOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Save</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
