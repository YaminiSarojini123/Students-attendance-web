import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { AppSidebar } from '@/components/layout/AppSidebar';
import { AppHeader } from '@/components/layout/AppHeader';
import { DashboardView } from '@/components/dashboard/DashboardView';
import { FaceScanView } from '@/components/attendance/FaceScanView';
import { RfidView } from '@/components/attendance/RfidView';
import { StudentsView } from '@/components/students/StudentsView';
import { StudentPortalView } from '@/components/portals/StudentPortalView';
import { ParentPortalView } from '@/components/portals/ParentPortalView';

const viewTitles: Record<string, string> = {
  dashboard: 'Dashboard',
  'face-scan': 'Face Recognition',
  rfid: 'RFID Terminal',
  students: 'Student Management',
  'student-portal': 'My Attendance',
  'parent-portal': 'Parent Portal',
};

export const MainApp: React.FC = () => {
  const { hasRole } = useAuth();
  const [activeView, setActiveView] = useState('dashboard');

  // Set initial view based on role
  useEffect(() => {
    if (hasRole('student')) {
      setActiveView('student-portal');
    } else if (hasRole('parent')) {
      setActiveView('parent-portal');
    } else {
      setActiveView('dashboard');
    }
  }, [hasRole]);

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView />;
      case 'face-scan':
        return <FaceScanView />;
      case 'rfid':
        return <RfidView />;
      case 'students':
        return <StudentsView />;
      case 'student-portal':
        return <StudentPortalView />;
      case 'parent-portal':
        return <ParentPortalView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden">
      <AppSidebar activeView={activeView} onViewChange={setActiveView} />
      
      <main className="flex flex-1 flex-col overflow-y-auto p-8">
        <AppHeader title={viewTitles[activeView] || 'Dashboard'} />
        {renderView()}
      </main>
    </div>
  );
};
