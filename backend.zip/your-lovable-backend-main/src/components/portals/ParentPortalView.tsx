import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Student, AttendanceLog } from '@/types/attendance';
import { StatCard } from '@/components/dashboard/StatCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { User, Search } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export const ParentPortalView: React.FC = () => {
  const { user } = useAuth();
  const [searchId, setSearchId] = useState('');
  const [linkedStudentId, setLinkedStudentId] = useState<string | null>(null);
  const [student, setStudent] = useState<Student | null>(null);
  const [logs, setLogs] = useState<AttendanceLog[]>([]);
  const [allDates, setAllDates] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  // Check for linked student on mount
  useEffect(() => {
    const checkLinkedStudent = async () => {
      if (!user) return;

      const { data } = await supabase
        .from('parent_student_links')
        .select('student_id')
        .eq('parent_id', user.id)
        .maybeSingle();

      if (data) {
        setLinkedStudentId(data.student_id);
        fetchStudentData(data.student_id);
      }
    };

    checkLinkedStudent();
  }, [user]);

  const fetchStudentData = async (studentId: string) => {
    setLoading(true);

    const { data: studentData } = await supabase
      .from('students')
      .select('*')
      .eq('id', studentId)
      .maybeSingle();

    if (studentData) {
      setStudent(studentData as Student);

      const { data: logsData } = await supabase
        .from('attendance_logs')
        .select('*')
        .eq('student_id', studentId)
        .order('date', { ascending: false });

      if (logsData) {
        setLogs(logsData as AttendanceLog[]);
      }

      // Get all unique dates
      const { data: allLogsData } = await supabase
        .from('attendance_logs')
        .select('date');

      if (allLogsData) {
        setAllDates(new Set(allLogsData.map((l) => l.date)));
      }

      setShowResults(true);
    } else {
      toast({
        title: 'Student not found',
        description: 'No student found with this ID',
        variant: 'destructive',
      });
      setShowResults(false);
    }

    setLoading(false);
  };

  const handleSearch = async () => {
    if (!searchId.trim()) return;

    const { data: studentData } = await supabase
      .from('students')
      .select('*')
      .eq('rfid_id', searchId.trim())
      .maybeSingle();

    if (studentData) {
      fetchStudentData(studentData.id);
    } else {
      toast({
        title: 'Student not found',
        description: 'No student found with this RFID',
        variant: 'destructive',
      });
      setShowResults(false);
    }
  };

  const presentDays = logs.length;
  const totalDays = allDates.size || 1;
  const absentDays = totalDays - presentDays;
  const percentage = Math.round((presentDays / totalDays) * 100);

  return (
    <div className="animate-fadeIn space-y-6">
      {/* Search Card */}
      <Card className="mx-auto max-w-md">
        <CardContent className="p-8 text-center">
          <User className="mx-auto mb-4 h-12 w-12 text-primary" strokeWidth={1.5} />
          <h2 className="mb-2 text-xl font-bold">Check Child's Attendance</h2>
          <p className="mb-6 text-muted-foreground">
            Enter the Student RFID or ID provided by the school.
          </p>

          <div className="flex gap-2">
            <Input
              placeholder="Enter Student ID (e.g., 101)"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch} disabled={loading}>
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {showResults && student && (
        <div className="space-y-6">
          {/* Student Info */}
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12 border-2 border-primary">
              <AvatarImage src={student.avatar_url || undefined} />
              <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-lg font-bold">{student.name}</h3>
              <p className="text-sm text-muted-foreground">ID: {student.rfid_id}</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid gap-6 sm:grid-cols-3">
            <StatCard title="Present" value={presentDays} variant="success" />
            <StatCard title="Attendance %" value={`${percentage}%`} />
            <StatCard title="Absent" value={absentDays} variant="danger" />
          </div>

          {/* Recent Logs */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Attendance Logs</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {logs.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  No attendance records yet.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Method</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.slice(0, 10).map((log) => (
                      <TableRow key={log.id}>
                        <TableCell>{log.date}</TableCell>
                        <TableCell>{log.time}</TableCell>
                        <TableCell>{log.method}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
