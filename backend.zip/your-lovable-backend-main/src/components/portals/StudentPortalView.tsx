import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Student, AttendanceLog } from '@/types/attendance';
import { StatCard } from '@/components/dashboard/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export const StudentPortalView: React.FC = () => {
  const { user } = useAuth();
  const [student, setStudent] = useState<Student | null>(null);
  const [logs, setLogs] = useState<AttendanceLog[]>([]);
  const [allDates, setAllDates] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStudentData = async () => {
      if (!user) return;

      // Find student linked to this user
      const { data: studentData } = await supabase
        .from('students')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (studentData) {
        setStudent(studentData as Student);

        // Get student's attendance logs
        const { data: logsData } = await supabase
          .from('attendance_logs')
          .select('*')
          .eq('student_id', studentData.id)
          .order('date', { ascending: false });

        if (logsData) {
          setLogs(logsData as AttendanceLog[]);
        }
      }

      // Get all unique dates for attendance calculation
      const { data: allLogsData } = await supabase
        .from('attendance_logs')
        .select('date');

      if (allLogsData) {
        setAllDates(new Set(allLogsData.map((l) => l.date)));
      }

      setLoading(false);
    };

    fetchStudentData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center text-muted-foreground">
        Loading...
      </div>
    );
  }

  if (!student) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-muted-foreground">
        <p>No student record found for your account.</p>
        <p className="text-sm">Please contact an administrator to link your account.</p>
      </div>
    );
  }

  const presentDays = logs.length;
  const totalDays = allDates.size || 1;
  const absentDays = totalDays - presentDays;
  const percentage = Math.round((presentDays / totalDays) * 100);

  return (
    <div className="animate-fadeIn space-y-6">
      {/* Stats */}
      <div className="grid gap-6 sm:grid-cols-3">
        <StatCard title="Total Present" value={presentDays} variant="success" />
        <StatCard title="Attendance %" value={`${percentage}%`} />
        <StatCard title="Total Absent" value={absentDays} variant="danger" />
      </div>

      {/* Attendance History */}
      <Card>
        <CardHeader>
          <CardTitle>My Attendance History</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {logs.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No attendance records yet.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>{log.date}</TableCell>
                    <TableCell>{log.time}</TableCell>
                    <TableCell>{log.method}</TableCell>
                    <TableCell>
                      <Badge className="bg-success/20 text-success hover:bg-success/30">
                        Present
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
