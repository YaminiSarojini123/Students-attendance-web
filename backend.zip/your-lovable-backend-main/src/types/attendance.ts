export type AppRole = 'admin' | 'teacher' | 'student' | 'parent';

export interface Profile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserRole {
  id: string;
  user_id: string;
  role: AppRole;
  created_at: string;
}

export interface Student {
  id: string;
  rfid_id: string;
  name: string;
  phone: string | null;
  avatar_url: string | null;
  user_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface AttendanceLog {
  id: string;
  student_id: string;
  date: string;
  time: string;
  method: string;
  marked_by: string | null;
  created_at: string;
}

export interface AttendanceLogWithStudent extends AttendanceLog {
  students: Student;
}

export interface ParentStudentLink {
  id: string;
  parent_id: string;
  student_id: string;
  created_at: string;
}

export interface DashboardStats {
  total: number;
  present: number;
  absent: number;
}
