import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Student } from '@/types/attendance';
import { toast } from '@/hooks/use-toast';

export const useStudents = () => {
  return useQuery({
    queryKey: ['students'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data as Student[];
    },
  });
};

export const useAddStudent = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (student: { rfid_id: string; name: string; phone?: string }) => {
      const avatarUrl = `https://picsum.photos/seed/${student.rfid_id}/200/200`;
      const { data, error } = await supabase
        .from('students')
        .insert({
          rfid_id: student.rfid_id,
          name: student.name,
          phone: student.phone || null,
          avatar_url: avatarUrl,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast({ title: 'Student added successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to add student', 
        description: error.message,
        variant: 'destructive' 
      });
    },
  });
};

export const useUpdateStudent = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, name, phone }: { id: string; name: string; phone?: string }) => {
      const { data, error } = await supabase
        .from('students')
        .update({ name, phone: phone || null })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast({ title: 'Student updated successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to update student', 
        description: error.message,
        variant: 'destructive' 
      });
    },
  });
};

export const useDeleteStudent = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('students')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      queryClient.invalidateQueries({ queryKey: ['attendance'] });
      toast({ title: 'Student deleted successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to delete student', 
        description: error.message,
        variant: 'destructive' 
      });
    },
  });
};
