import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AttendanceLog, AttendanceLogWithStudent, Student } from '@/types/attendance';
import { toast } from '@/hooks/use-toast';
import { useEffect } from 'react';

export const useAttendanceLogs = (date: string) => {
  const queryClient = useQueryClient();

  useEffect(() => {
    const channel = supabase
      .channel('attendance-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance_logs',
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['attendance', date] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient, date]);

  return useQuery({
    queryKey: ['attendance', date],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('attendance_logs')
        .select('*, students(*)')
        .eq('date', date)
        .order('time', { ascending: false });
      
      if (error) throw error;
      return data as AttendanceLogWithStudent[];
    },
  });
};

export const useStudentAttendance = (studentId: string | undefined) => {
  return useQuery({
    queryKey: ['student-attendance', studentId],
    queryFn: async () => {
      if (!studentId) return [];
      
      const { data, error } = await supabase
        .from('attendance_logs')
        .select('*')
        .eq('student_id', studentId)
        .order('date', { ascending: false });
      
      if (error) throw error;
      return data as AttendanceLog[];
    },
    enabled: !!studentId,
  });
};

export const useMarkAttendance = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      studentId, 
      method, 
      date 
    }: { 
      studentId: string; 
      method: string; 
      date: string;
    }) => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
      });

      const { data, error } = await supabase
        .from('attendance_logs')
        .insert({
          student_id: studentId,
          method,
          date,
          time: timeStr,
        })
        .select('*, students(*)')
        .single();
      
      if (error) throw error;
      return data as AttendanceLogWithStudent;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['attendance'] });
      toast({ 
        title: `${data.students.name} marked present`,
        description: `Method: ${data.method}`,
      });
    },
    onError: (error: Error) => {
      if (error.message.includes('duplicate')) {
        toast({ 
          title: 'Already marked present', 
          description: 'This student is already marked present for today',
          variant: 'destructive' 
        });
      } else {
        toast({ 
          title: 'Failed to mark attendance', 
          description: error.message,
          variant: 'destructive' 
        });
      }
    },
  });
};

export const useStudentByRfid = () => {
  return useMutation({
    mutationFn: async (rfidId: string) => {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('rfid_id', rfidId)
        .maybeSingle();
      
      if (error) throw error;
      if (!data) throw new Error('Student not found');
      return data as Student;
    },
  });
};
